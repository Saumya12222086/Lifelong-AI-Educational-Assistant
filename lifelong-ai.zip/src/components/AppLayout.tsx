import { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { AppSidebar } from "./AppSidebar";
import { useAuth } from "@/hooks/useAuth";

export const AppLayout = ({ children }: { children: ReactNode }) => {
  const { user, loading } = useAuth();

  if (loading) return <div className="min-h-screen bg-gradient-soft" />;
  if (!user) return <Navigate to="/auth" replace />;

  return (
    <div className="min-h-screen bg-gradient-mesh flex flex-col lg:flex-row">
      <AppSidebar />
      <main className="flex-1 min-w-0 animate-fade-in">
        <div className="max-w-7xl mx-auto p-6 lg:p-10">{children}</div>
      </main>
    </div>
  );
};
