import { useState, useEffect } from "react";

export type LearningLevel = "Beginner" | "Intermediate" | "Advanced" | "Research";

export interface User {
  name: string;
  email: string;
  level: LearningLevel;
  interests: string[];
  xp: number;
  streak: number;
  joinedAt: string;
}

const KEY = "laai_user";

const defaultUser = (name: string, email: string): User => ({
  name,
  email,
  level: "Beginner",
  interests: ["Mathematics", "Science"],
  xp: 1240,
  streak: 7,
  joinedAt: new Date().toISOString(),
});

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const raw = localStorage.getItem(KEY);
    if (raw) setUser(JSON.parse(raw));
    setLoading(false);
  }, []);

  const signup = (name: string, email: string) => {
    const u = defaultUser(name, email);
    localStorage.setItem(KEY, JSON.stringify(u));
    setUser(u);
    return u;
  };

  const login = (email: string) => {
    const raw = localStorage.getItem(KEY);
    const existing = raw ? (JSON.parse(raw) as User) : null;
    const u = existing && existing.email === email ? existing : defaultUser(email.split("@")[0], email);
    localStorage.setItem(KEY, JSON.stringify(u));
    setUser(u);
    return u;
  };

  const logout = () => {
    localStorage.removeItem(KEY);
    setUser(null);
  };

  const update = (patch: Partial<User>) => {
    setUser((prev) => {
      if (!prev) return prev;
      const next = { ...prev, ...patch };
      localStorage.setItem(KEY, JSON.stringify(next));
      return next;
    });
  };

  return { user, loading, signup, login, logout, update };
}
