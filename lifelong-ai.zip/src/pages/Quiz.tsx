import { useState } from "react";
import { Link } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, Trophy, ArrowRight, RotateCcw } from "lucide-react";

const questions = [
  {
    q: "What is the basic computational unit of a neural network?",
    options: ["Neuron", "Pixel", "Token", "Vector"],
    answer: 0,
    explain: "Neurons receive inputs, apply weights and an activation function, and pass output forward.",
  },
  {
    q: "What does 'training' a neural network mean?",
    options: ["Building hardware", "Adjusting weights to reduce error", "Adding more layers", "Coloring outputs"],
    answer: 1,
    explain: "Training adjusts internal weights based on the difference between predictions and the correct answers.",
  },
  {
    q: "Which is a real-world use of neural networks?",
    options: ["Image recognition", "Boiling water", "Mowing lawns mechanically", "Solving riddles by hand"],
    answer: 0,
    explain: "Image recognition, translation, and recommendations are all powered by neural networks today.",
  },
  {
    q: "Backpropagation is used to…",
    options: ["Plot graphs", "Send signals back to update weights", "Replace data", "Cool the GPU"],
    answer: 1,
    explain: "Backpropagation computes gradients backward through the network so weights can be updated.",
  },
];

const Quiz = () => {
  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  const q = questions[idx];
  const progress = ((idx + (selected !== null ? 1 : 0)) / questions.length) * 100;

  const choose = (i: number) => {
    if (selected !== null) return;
    setSelected(i);
    if (i === q.answer) setScore((s) => s + 1);
  };

  const next = () => {
    if (idx + 1 >= questions.length) {
      setDone(true);
    } else {
      setIdx(idx + 1);
      setSelected(null);
    }
  };

  const reset = () => { setIdx(0); setSelected(null); setScore(0); setDone(false); };

  if (done) {
    const pct = Math.round((score / questions.length) * 100);
    const great = pct >= 75;
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto bg-card rounded-3xl shadow-elegant p-10 text-center animate-scale-in">
          <div className="w-20 h-20 mx-auto rounded-full bg-gradient-primary flex items-center justify-center mb-6 shadow-glow">
            <Trophy className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="font-display text-4xl font-bold mb-2">{great ? "Brilliant work!" : "Good effort!"}</h1>
          <p className="text-muted-foreground mb-6">You scored {score} of {questions.length} ({pct}%)</p>
          <div className="h-3 rounded-full bg-muted overflow-hidden mb-8 max-w-xs mx-auto">
            <div className="h-full bg-gradient-primary" style={{ width: `${pct}%` }} />
          </div>
          <p className="text-sm text-muted-foreground mb-6">
            {great ? "Your AI is leveling up the difficulty for next time." : "Your AI will reinforce the basics in your next session."}
          </p>
          <div className="flex gap-3 justify-center flex-wrap">
            <Button variant="hero" onClick={reset}><RotateCcw /> Retry</Button>
            <Link to="/dashboard"><Button variant="outline">Back to dashboard <ArrowRight /></Button></Link>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div>
          <div className="flex justify-between text-sm text-muted-foreground mb-2">
            <span>Question {idx + 1} of {questions.length}</span>
            <span>Score: {score}</span>
          </div>
          <div className="h-2 rounded-full bg-muted overflow-hidden">
            <div className="h-full bg-gradient-primary transition-all duration-500" style={{ width: `${progress}%` }} />
          </div>
        </div>

        <div className="bg-card rounded-3xl p-8 shadow-soft animate-fade-in-up" key={idx}>
          <h2 className="font-display text-2xl font-bold mb-6">{q.q}</h2>
          <div className="space-y-3">
            {q.options.map((opt, i) => {
              const isAns = i === q.answer;
              const isSel = i === selected;
              const showState = selected !== null;
              return (
                <button
                  key={i}
                  onClick={() => choose(i)}
                  disabled={selected !== null}
                  className={`w-full text-left p-4 rounded-2xl border-2 font-medium transition-smooth flex items-center justify-between ${
                    showState && isAns ? "border-success bg-success/10 text-success" :
                    showState && isSel && !isAns ? "border-destructive bg-destructive/10 text-destructive" :
                    isSel ? "border-primary bg-accent" :
                    "border-border hover:border-primary/30 hover:bg-accent/50"
                  }`}
                >
                  <span>{opt}</span>
                  {showState && isAns && <CheckCircle2 className="w-5 h-5" />}
                  {showState && isSel && !isAns && <XCircle className="w-5 h-5" />}
                </button>
              );
            })}
          </div>

          {selected !== null && (
            <div className="mt-6 p-4 rounded-2xl bg-accent/50 border border-primary/10 animate-fade-in">
              <div className="font-semibold text-sm mb-1 text-accent-foreground">
                {selected === q.answer ? "✓ Correct!" : "Not quite"}
              </div>
              <p className="text-sm text-muted-foreground">{q.explain}</p>
            </div>
          )}
        </div>

        {selected !== null && (
          <div className="flex justify-end">
            <Button variant="hero" onClick={next}>
              {idx + 1 >= questions.length ? "See results" : "Next question"} <ArrowRight />
            </Button>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Quiz;
