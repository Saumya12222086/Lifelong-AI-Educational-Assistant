import { Link } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { useAuth, LearningLevel } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { Check, Sparkles, ArrowRight } from "lucide-react";

const levels: { name: LearningLevel; tagline: string; color: string; topics: string[] }[] = [
  { name: "Beginner", tagline: "Curious starters & K-12", color: "from-blue-400 to-cyan-500", topics: ["Basic Math", "Reading", "Science Wonder", "Logic Puzzles"] },
  { name: "Intermediate", tagline: "High school & early college", color: "from-indigo-400 to-purple-500", topics: ["Algebra", "Programming", "Biology", "Essay Writing"] },
  { name: "Advanced", tagline: "Specialization & university", color: "from-purple-400 to-fuchsia-500", topics: ["Calculus", "Data Structures", "Quantum Basics", "Critical Theory"] },
  { name: "Research", tagline: "Graduate & beyond", color: "from-fuchsia-500 to-pink-500", topics: ["Paper Review", "Thesis Drafting", "Grant Writing", "Open Problems"] },
];

const interests = ["Mathematics", "Computer Science", "Physics", "Biology", "History", "Linguistics", "Philosophy", "Engineering"];

const Learn = () => {
  const { user, update } = useAuth();

  const setLevel = (level: LearningLevel) => {
    update({ level });
    toast({ title: `Path updated`, description: `Your AI is calibrating to ${level} level.` });
  };

  const toggleInterest = (i: string) => {
    if (!user) return;
    const next = user.interests.includes(i) ? user.interests.filter((x) => x !== i) : [...user.interests, i];
    update({ interests: next });
  };

  return (
    <AppLayout>
      <div className="space-y-10">
        <div className="animate-fade-in-up">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-medium mb-3">
            <Sparkles className="w-3 h-3" /> Personalized for you
          </div>
          <h1 className="font-display text-4xl font-bold">Choose your learning path</h1>
          <p className="text-muted-foreground mt-2">Your AI adapts content, depth, and pace based on your selections.</p>
        </div>

        {/* Levels */}
        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-5">
          {levels.map((l) => {
            const active = user?.level === l.name;
            return (
              <button
                key={l.name}
                onClick={() => setLevel(l.name)}
                className={`text-left bg-card rounded-3xl p-6 shadow-soft transition-spring hover:-translate-y-1 hover:shadow-elegant border-2 ${
                  active ? "border-primary shadow-glow" : "border-transparent"
                }`}
              >
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${l.color} mb-4 flex items-center justify-center text-white font-display font-bold`}>
                  {l.name.charAt(0)}
                </div>
                <div className="flex items-center justify-between">
                  <h3 className="font-display font-bold text-lg">{l.name}</h3>
                  {active && <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center"><Check className="w-3.5 h-3.5 text-primary-foreground" /></div>}
                </div>
                <p className="text-sm text-muted-foreground mb-4">{l.tagline}</p>
                <div className="flex flex-wrap gap-1.5">
                  {l.topics.map((t) => (
                    <span key={t} className="text-xs px-2 py-1 rounded-md bg-muted text-muted-foreground">{t}</span>
                  ))}
                </div>
              </button>
            );
          })}
        </div>

        {/* Interests */}
        <div className="bg-card rounded-3xl p-6 shadow-soft">
          <h2 className="font-display font-bold text-xl mb-1">Your interests</h2>
          <p className="text-sm text-muted-foreground mb-4">Tap to refine your AI tutor's focus.</p>
          <div className="flex flex-wrap gap-2">
            {interests.map((i) => {
              const active = user?.interests.includes(i);
              return (
                <button
                  key={i}
                  onClick={() => toggleInterest(i)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-smooth ${
                    active ? "bg-gradient-primary text-primary-foreground shadow-soft" : "bg-muted text-muted-foreground hover:bg-accent"
                  }`}
                >
                  {i}
                </button>
              );
            })}
          </div>
        </div>

        {/* Recommended */}
        <div className="bg-gradient-card rounded-3xl p-6 shadow-soft border border-border/50">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="font-display font-bold text-xl">Recommended for you</h2>
              <p className="text-sm text-muted-foreground">Based on {user?.level} level + your interests</p>
            </div>
            <Link to="/module"><Button variant="hero">Start next lesson <ArrowRight /></Button></Link>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { title: "Neural Networks 101", time: "12 min", level: user?.level },
              { title: "Probability Foundations", time: "18 min", level: user?.level },
              { title: "Critical Thinking Toolkit", time: "9 min", level: user?.level },
            ].map((m) => (
              <Link key={m.title} to="/module" className="group bg-card rounded-2xl p-5 shadow-soft hover:shadow-elegant transition-spring hover:-translate-y-1">
                <div className="aspect-video rounded-xl bg-gradient-primary mb-3 flex items-center justify-center">
                  <Sparkles className="w-8 h-8 text-primary-foreground" />
                </div>
                <div className="font-display font-bold mb-1 group-hover:text-primary transition-smooth">{m.title}</div>
                <div className="text-xs text-muted-foreground">{m.time} · {m.level}</div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default Learn;
