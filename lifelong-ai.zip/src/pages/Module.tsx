import { Link } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { CheckCircle2, PlayCircle, BookOpen, ArrowRight } from "lucide-react";
import { useState } from "react";

const sections = [
  { id: 1, title: "What is a Neural Network?" },
  { id: 2, title: "Neurons & Layers" },
  { id: 3, title: "Training & Backpropagation" },
  { id: 4, title: "Real-world Applications" },
];

const Module = () => {
  const [active, setActive] = useState(1);
  const [completed, setCompleted] = useState<number[]>([]);

  const markDone = () => {
    if (!completed.includes(active)) setCompleted([...completed, active]);
    if (active < sections.length) setActive(active + 1);
  };

  const progress = (completed.length / sections.length) * 100;

  return (
    <AppLayout>
      <div className="grid lg:grid-cols-[280px_1fr] gap-8">
        {/* Outline */}
        <aside className="space-y-4">
          <div>
            <div className="text-xs text-muted-foreground mb-1">Module · 12 min</div>
            <h2 className="font-display font-bold text-xl">Neural Networks 101</h2>
          </div>
          <div className="bg-card rounded-2xl p-4 shadow-soft">
            <div className="flex justify-between text-xs text-muted-foreground mb-2">
              <span>Progress</span><span>{Math.round(progress)}%</span>
            </div>
            <div className="h-2 rounded-full bg-muted overflow-hidden">
              <div className="h-full bg-gradient-primary transition-all duration-700" style={{ width: `${progress}%` }} />
            </div>
          </div>
          <nav className="space-y-1">
            {sections.map((s) => {
              const done = completed.includes(s.id);
              const isActive = active === s.id;
              return (
                <button
                  key={s.id}
                  onClick={() => setActive(s.id)}
                  className={`w-full text-left flex items-center gap-3 px-3 py-3 rounded-xl text-sm transition-smooth ${
                    isActive ? "bg-accent text-accent-foreground font-semibold" : "text-muted-foreground hover:bg-muted"
                  }`}
                >
                  {done ? <CheckCircle2 className="w-4 h-4 text-success" /> : <div className="w-4 h-4 rounded-full border-2 border-current opacity-50" />}
                  <span>{s.title}</span>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Content */}
        <article className="space-y-6 animate-fade-in-up">
          <div className="bg-card rounded-3xl p-8 shadow-soft">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-medium mb-4">
              <BookOpen className="w-3 h-3" /> Section {active} of {sections.length}
            </div>
            <h1 className="font-display text-4xl font-bold mb-6">{sections.find((s) => s.id === active)?.title}</h1>

            {/* Video placeholder */}
            <div className="aspect-video rounded-2xl bg-gradient-hero flex items-center justify-center mb-6 relative overflow-hidden group cursor-pointer">
              <div className="absolute inset-0 bg-gradient-mesh opacity-40" />
              <div className="relative w-20 h-20 rounded-full bg-white/20 backdrop-blur flex items-center justify-center group-hover:scale-110 transition-spring">
                <PlayCircle className="w-12 h-12 text-white" />
              </div>
            </div>

            <div className="prose prose-lg max-w-none text-foreground space-y-4">
              <p className="text-lg leading-relaxed">
                A <strong>neural network</strong> is a computing system loosely inspired by the biological brain.
                It learns patterns from data through layers of interconnected nodes called <em>neurons</em>.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Each neuron receives input, applies a weight, and passes the signal through an activation function.
                Stack thousands of these in <strong>layers</strong> and you can recognize images, translate languages,
                or generate text — all from learned patterns rather than explicit rules.
              </p>

              <div className="not-prose bg-accent/50 rounded-2xl p-5 my-6 border border-primary/10">
                <div className="font-semibold mb-2 text-accent-foreground">💡 Key insight</div>
                <p className="text-sm">
                  Neural networks don't memorize answers — they learn <em>functions</em> that map inputs to outputs.
                  That's why they generalize to data they've never seen.
                </p>
              </div>

              <h3 className="font-display text-2xl font-bold mt-6">Why it matters</h3>
              <p className="text-muted-foreground leading-relaxed">
                From the recommendation in your music app to medical image diagnosis, neural networks quietly power
                the modern world. Understanding their basics is your first step into the AI era.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 bg-card rounded-2xl p-5 shadow-soft">
            <div className="text-sm text-muted-foreground">
              {completed.includes(active) ? "✅ Completed" : "Mark this section complete to continue"}
            </div>
            <div className="flex gap-3">
              {active === sections.length && completed.length === sections.length ? (
                <Link to="/quiz"><Button variant="hero">Take the quiz <ArrowRight /></Button></Link>
              ) : (
                <Button variant="hero" onClick={markDone}>
                  {active === sections.length ? "Complete module" : "Mark complete & next"} <ArrowRight />
                </Button>
              )}
            </div>
          </div>
        </article>
      </div>
    </AppLayout>
  );
};

export default Module;
