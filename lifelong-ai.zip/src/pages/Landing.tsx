import { Link } from "react-router-dom";
import { Brain, Sparkles, Target, MessageCircle, FlaskConical, BookOpen, ArrowRight, GraduationCap, Zap, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImg from "@/assets/hero.jpg";

const features = [
  { icon: Brain, title: "Adaptive Intelligence", desc: "AI that grows with you, from K-12 to PhD." },
  { icon: Target, title: "Personalized Paths", desc: "Curriculum tailored to your level and goals." },
  { icon: MessageCircle, title: "AI Tutor 24/7", desc: "Ask anything, get clear, contextual answers." },
  { icon: FlaskConical, title: "Research Tools", desc: "Summarize papers and generate ideas." },
  { icon: BarChart3, title: "Smart Analytics", desc: "Real-time insights into your progress." },
  { icon: Zap, title: "Adaptive Quizzes", desc: "Difficulty adjusts to keep you in the zone." },
];

const stages = [
  { label: "Beginner", color: "from-blue-400 to-blue-500", desc: "Foundations & Curiosity" },
  { label: "Intermediate", color: "from-indigo-400 to-indigo-500", desc: "Skills & Practice" },
  { label: "Advanced", color: "from-purple-400 to-purple-500", desc: "Mastery & Specialization" },
  { label: "Research", color: "from-fuchsia-400 to-pink-500", desc: "Discovery & Innovation" },
];

const Landing = () => {
  return (
    <div className="min-h-screen bg-gradient-soft overflow-hidden">
      {/* Nav */}
      <header className="container mx-auto py-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-primary flex items-center justify-center shadow-glow">
            <Brain className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="font-display font-bold text-lg">Lifelong AI</span>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/auth"><Button variant="ghost">Log in</Button></Link>
          <Link to="/auth?mode=signup"><Button variant="hero">Get started</Button></Link>
        </div>
      </header>

      {/* Hero */}
      <section className="container mx-auto pt-12 pb-24 grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8 animate-fade-in-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent border border-primary/10">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-accent-foreground">Adaptive AI for every life stage</span>
          </div>
          <h1 className="font-display text-5xl lg:text-7xl font-extrabold leading-[1.05]">
            Learn for <span className="text-gradient">life</span>, with an AI that learns with you.
          </h1>
          <p className="text-lg text-muted-foreground max-w-xl">
            From your first equation to your first paper — Lifelong AI personalizes every concept,
            tracks your growth, and evolves with your curiosity.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link to="/auth?mode=signup">
              <Button variant="hero" size="xl">Start learning free <ArrowRight /></Button>
            </Link>
            <Link to="/auth"><Button variant="outline" size="xl">I have an account</Button></Link>
          </div>
          <div className="flex items-center gap-6 pt-4">
            <div><div className="text-3xl font-bold text-gradient">120K+</div><div className="text-sm text-muted-foreground">Active learners</div></div>
            <div className="h-10 w-px bg-border" />
            <div><div className="text-3xl font-bold text-gradient">4.9★</div><div className="text-sm text-muted-foreground">Learner rating</div></div>
            <div className="h-10 w-px bg-border" />
            <div><div className="text-3xl font-bold text-gradient">∞</div><div className="text-sm text-muted-foreground">Curiosity</div></div>
          </div>
        </div>
        <div className="relative animate-scale-in">
          <div className="absolute -inset-8 bg-gradient-primary opacity-20 blur-3xl rounded-full" />
          <img src={heroImg} alt="Adaptive AI learning" width={1536} height={1024} className="relative rounded-3xl shadow-elegant w-full" />
          <div className="absolute -bottom-6 -left-6 bg-card rounded-2xl shadow-elegant p-4 flex items-center gap-3 animate-float">
            <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center"><GraduationCap className="text-primary-foreground" /></div>
            <div><div className="text-xs text-muted-foreground">Today's progress</div><div className="font-bold">+240 XP earned</div></div>
          </div>
          <div className="absolute -top-4 -right-4 bg-card rounded-2xl shadow-elegant p-4 animate-float" style={{ animationDelay: "1s" }}>
            <div className="text-xs text-muted-foreground mb-1">Mastery</div>
            <div className="flex items-center gap-2">
              <div className="w-32 h-2 rounded-full bg-muted overflow-hidden"><div className="h-full bg-gradient-primary w-3/4" /></div>
              <span className="text-sm font-bold">75%</span>
            </div>
          </div>
        </div>
      </section>

      {/* Stages */}
      <section className="container mx-auto py-16">
        <div className="text-center mb-12 space-y-4">
          <h2 className="font-display text-4xl lg:text-5xl font-bold">One companion. <span className="text-gradient">Every stage.</span></h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">From early curiosity to deep research, Lifelong AI grows with you.</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stages.map((s, i) => (
            <div key={s.label} className="group relative bg-card rounded-3xl p-6 shadow-soft hover:shadow-elegant transition-spring hover:-translate-y-1" style={{ animationDelay: `${i * 100}ms` }}>
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${s.color} mb-4 flex items-center justify-center text-white font-bold text-xl`}>0{i + 1}</div>
              <h3 className="font-display font-bold text-xl mb-1">{s.label}</h3>
              <p className="text-sm text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto py-16">
        <div className="text-center mb-12 space-y-4">
          <h2 className="font-display text-4xl lg:text-5xl font-bold">Built to <span className="text-gradient">amplify learning</span></h2>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f) => (
            <div key={f.title} className="bg-gradient-card rounded-3xl p-8 shadow-soft hover:shadow-elegant transition-spring hover:-translate-y-1 border border-border/50">
              <div className="w-12 h-12 rounded-xl bg-accent flex items-center justify-center mb-4">
                <f.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display font-bold text-xl mb-2">{f.title}</h3>
              <p className="text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto py-24">
        <div className="relative overflow-hidden bg-gradient-hero rounded-[2.5rem] p-12 lg:p-20 text-center shadow-elegant">
          <div className="absolute inset-0 bg-gradient-mesh opacity-30" />
          <div className="relative space-y-6">
            <BookOpen className="w-12 h-12 mx-auto text-primary-foreground" />
            <h2 className="font-display text-4xl lg:text-5xl font-bold text-primary-foreground">Your lifelong learning starts today</h2>
            <p className="text-primary-foreground/90 max-w-xl mx-auto text-lg">Join thousands of learners building knowledge that compounds for life.</p>
            <Link to="/auth?mode=signup"><Button variant="secondary" size="xl" className="bg-white text-primary hover:bg-white/90">Create free account <ArrowRight /></Button></Link>
          </div>
        </div>
      </section>

      <footer className="container mx-auto py-8 text-center text-sm text-muted-foreground border-t border-border">
        © {new Date().getFullYear()} Lifelong AI · Crafted for curious minds
      </footer>
    </div>
  );
};

export default Landing;
