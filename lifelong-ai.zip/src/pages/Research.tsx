import { useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { FlaskConical, FileText, Lightbulb, BookMarked, Sparkles, Lock } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "react-router-dom";

const Research = () => {
  const { user } = useAuth();
  const advanced = user?.level === "Advanced" || user?.level === "Research";

  const [paper, setPaper] = useState("");
  const [summary, setSummary] = useState("");
  const [topic, setTopic] = useState("");
  const [ideas, setIdeas] = useState<string[]>([]);

  const summarize = () => {
    if (!paper.trim()) return;
    setSummary(
      `📄 Adaptive Summary\n\nThis paper explores ${paper.slice(0, 60).toLowerCase()}... The authors argue that the proposed framework outperforms prior baselines by 18.4% on benchmark datasets.\n\nKey contributions:\n• A novel architecture combining attention with structured reasoning\n• Empirical validation across three domains\n• Open-sourced reproducible code\n\nLimitations: small sample size and limited cross-cultural evaluation.`
    );
  };

  const generateIdeas = () => {
    if (!topic.trim()) return;
    setIdeas([
      `Investigate whether ${topic} generalizes to low-resource settings.`,
      `Build a benchmark dataset for ${topic} across 3 domains.`,
      `Combine ${topic} with self-supervised pretraining for robustness.`,
      `Study ethical implications and bias in ${topic} systems.`,
      `Explore a hybrid symbolic + neural approach to ${topic}.`,
    ]);
  };

  if (!advanced) {
    return (
      <AppLayout>
        <div className="max-w-xl mx-auto text-center bg-card rounded-3xl p-10 shadow-soft animate-scale-in">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-accent flex items-center justify-center mb-6">
            <Lock className="w-8 h-8 text-primary" />
          </div>
          <h1 className="font-display text-3xl font-bold mb-3">Research Lab is unlocking…</h1>
          <p className="text-muted-foreground mb-6">
            This space is reserved for <strong>Advanced</strong> and <strong>Research</strong> learners.
            Upgrade your learning path to access paper summaries, idea generation, and more.
          </p>
          <Link to="/learn"><Button variant="hero">Upgrade my path <Sparkles /></Button></Link>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-8">
        <div className="animate-fade-in-up">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-medium mb-3">
            <FlaskConical className="w-3 h-3" /> Advanced toolkit
          </div>
          <h1 className="font-display text-4xl font-bold">Research Lab</h1>
          <p className="text-muted-foreground mt-2">Tools for deep work — summarize papers, generate ideas, explore frontiers.</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Summarizer */}
          <div className="bg-card rounded-3xl p-6 shadow-soft space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-gradient-primary flex items-center justify-center"><FileText className="w-5 h-5 text-primary-foreground" /></div>
              <div>
                <h2 className="font-display font-bold text-lg">Paper Summarizer</h2>
                <p className="text-xs text-muted-foreground">Paste an abstract or title</p>
              </div>
            </div>
            <Textarea value={paper} onChange={(e) => setPaper(e.target.value)} placeholder="Paste paper abstract..." rows={5} />
            <Button variant="hero" onClick={summarize} className="w-full">Summarize</Button>
            {summary && (
              <div className="bg-accent/50 rounded-2xl p-4 text-sm whitespace-pre-line border border-primary/10 animate-fade-in">{summary}</div>
            )}
          </div>

          {/* Idea generator */}
          <div className="bg-card rounded-3xl p-6 shadow-soft space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-gradient-primary flex items-center justify-center"><Lightbulb className="w-5 h-5 text-primary-foreground" /></div>
              <div>
                <h2 className="font-display font-bold text-lg">Idea Generator</h2>
                <p className="text-xs text-muted-foreground">Spark new research directions</p>
              </div>
            </div>
            <Input value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="e.g. graph neural networks" className="h-12" />
            <Button variant="hero" onClick={generateIdeas} className="w-full">Generate 5 ideas</Button>
            {ideas.length > 0 && (
              <ul className="space-y-2 animate-fade-in">
                {ideas.map((i, k) => (
                  <li key={k} className="flex gap-3 p-3 rounded-xl bg-accent/40 text-sm">
                    <span className="font-bold text-primary">{k + 1}.</span>
                    <span>{i}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* Saved corpus */}
        <div className="bg-gradient-card rounded-3xl p-6 shadow-soft border border-border/50">
          <div className="flex items-center gap-3 mb-4">
            <BookMarked className="w-5 h-5 text-primary" />
            <h2 className="font-display font-bold text-lg">Your reading list</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { title: "Attention Is All You Need", authors: "Vaswani et al., 2017", tag: "NLP" },
              { title: "Deep Residual Learning", authors: "He et al., 2015", tag: "Vision" },
              { title: "GANs", authors: "Goodfellow et al., 2014", tag: "Generative" },
            ].map((p) => (
              <div key={p.title} className="bg-card rounded-2xl p-4 shadow-soft hover:shadow-elegant transition-smooth">
                <div className="text-xs text-primary font-medium mb-1">{p.tag}</div>
                <div className="font-display font-bold text-sm mb-1">{p.title}</div>
                <div className="text-xs text-muted-foreground">{p.authors}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default Research;
