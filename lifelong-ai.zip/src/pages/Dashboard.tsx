import { Link } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Target, MessageCircle, FlaskConical, Flame, Trophy, TrendingUp, Sparkles } from "lucide-react";

const subjects = [
  { name: "Mathematics", progress: 78, color: "from-blue-400 to-indigo-500" },
  { name: "Computer Science", progress: 64, color: "from-purple-400 to-fuchsia-500" },
  { name: "Physics", progress: 45, color: "from-cyan-400 to-blue-500" },
  { name: "Linguistics", progress: 32, color: "from-pink-400 to-rose-500" },
];

const weekXp = [120, 80, 200, 150, 90, 220, 240];
const days = ["M", "T", "W", "T", "F", "S", "S"];

const Dashboard = () => {
  const { user } = useAuth();
  const max = Math.max(...weekXp);

  return (
    <AppLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 animate-fade-in-up">
          <div>
            <p className="text-muted-foreground">Welcome back,</p>
            <h1 className="font-display text-4xl font-bold">{user?.name} 👋</h1>
            <p className="text-muted-foreground mt-1">Your AI is ready when you are.</p>
          </div>
          <div className="flex gap-3 flex-wrap">
            <Link to="/learn"><Button variant="hero">Continue learning</Button></Link>
            <Link to="/chat"><Button variant="outline">Ask AI Tutor</Button></Link>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: Trophy, label: "XP", value: user?.xp.toLocaleString(), tint: "from-amber-400 to-orange-500" },
            { icon: Flame, label: "Streak", value: `${user?.streak} days`, tint: "from-rose-400 to-red-500" },
            { icon: Sparkles, label: "Level", value: user?.level, tint: "from-purple-400 to-fuchsia-500" },
            { icon: TrendingUp, label: "Mastery", value: "72%", tint: "from-emerald-400 to-teal-500" },
          ].map((s) => (
            <div key={s.label} className="bg-card rounded-2xl p-5 shadow-soft hover:shadow-elegant transition-smooth">
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${s.tint} flex items-center justify-center mb-3`}>
                <s.icon className="w-5 h-5 text-white" />
              </div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
              <div className="font-display font-bold text-2xl">{s.value}</div>
            </div>
          ))}
        </div>

        {/* Main grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Progress */}
          <div className="lg:col-span-2 bg-card rounded-3xl p-6 shadow-soft">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display font-bold text-xl">Your subjects</h2>
              <Link to="/learn"><Button variant="ghost" size="sm">View all</Button></Link>
            </div>
            <div className="space-y-5">
              {subjects.map((s) => (
                <div key={s.name}>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{s.name}</span>
                    <span className="text-sm text-muted-foreground">{s.progress}%</span>
                  </div>
                  <div className="h-3 rounded-full bg-muted overflow-hidden">
                    <div className={`h-full bg-gradient-to-r ${s.color} transition-all duration-1000`} style={{ width: `${s.progress}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Weekly */}
          <div className="bg-gradient-primary rounded-3xl p-6 shadow-elegant text-primary-foreground">
            <h2 className="font-display font-bold text-xl mb-1">This week</h2>
            <p className="text-sm text-primary-foreground/80 mb-6">+1,100 XP earned</p>
            <div className="flex items-end justify-between gap-2 h-32">
              {weekXp.map((xp, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-2">
                  <div className="w-full rounded-lg bg-white/20 hover:bg-white/30 transition-smooth" style={{ height: `${(xp / max) * 100}%` }} />
                  <span className="text-xs opacity-80">{days[i]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick actions */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { to: "/module", icon: BookOpen, title: "Learning Module", desc: "Today's lesson" },
            { to: "/quiz", icon: Target, title: "Adaptive Quiz", desc: "Test your skills" },
            { to: "/chat", icon: MessageCircle, title: "AI Chat", desc: "Ask anything" },
            { to: "/research", icon: FlaskConical, title: "Research Lab", desc: "Advanced tools" },
          ].map((a) => (
            <Link key={a.to} to={a.to} className="group bg-card rounded-2xl p-5 shadow-soft hover:shadow-elegant transition-spring hover:-translate-y-1">
              <div className="w-11 h-11 rounded-xl bg-accent flex items-center justify-center mb-3 group-hover:bg-gradient-primary transition-smooth">
                <a.icon className="w-5 h-5 text-primary group-hover:text-primary-foreground" />
              </div>
              <div className="font-display font-bold">{a.title}</div>
              <div className="text-sm text-muted-foreground">{a.desc}</div>
            </Link>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default Dashboard;
