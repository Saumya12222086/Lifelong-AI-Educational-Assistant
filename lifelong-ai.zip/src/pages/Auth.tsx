import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Brain, Mail, Lock, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";

const Auth = () => {
  const [params] = useSearchParams();
  const [mode, setMode] = useState<"login" | "signup">(params.get("mode") === "signup" ? "signup" : "login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login, signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || (mode === "signup" && !name)) {
      toast({ title: "Please fill out all fields" });
      return;
    }
    if (mode === "signup") {
      signup(name, email);
      toast({ title: `Welcome, ${name}!`, description: "Your learning journey begins now." });
    } else {
      login(email);
      toast({ title: "Welcome back!" });
    }
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-gradient-mesh flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <Link to="/" className="flex items-center gap-3 justify-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-glow">
            <Brain className="w-6 h-6 text-primary-foreground" />
          </div>
          <span className="font-display font-bold text-2xl">Lifelong AI</span>
        </Link>

        <div className="bg-card rounded-3xl shadow-elegant p-8 animate-scale-in">
          <div className="text-center mb-6">
            <h1 className="font-display text-3xl font-bold mb-2">
              {mode === "login" ? "Welcome back" : "Begin your journey"}
            </h1>
            <p className="text-muted-foreground text-sm">
              {mode === "login" ? "Pick up where you left off." : "Create your adaptive AI account."}
            </p>
          </div>

          <div className="flex p-1 bg-muted rounded-xl mb-6">
            <button
              onClick={() => setMode("login")}
              className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-smooth ${mode === "login" ? "bg-card shadow-soft text-foreground" : "text-muted-foreground"}`}
            >Log in</button>
            <button
              onClick={() => setMode("signup")}
              className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-smooth ${mode === "signup" ? "bg-card shadow-soft text-foreground" : "text-muted-foreground"}`}
            >Sign up</button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "signup" && (
              <div className="space-y-2">
                <Label htmlFor="name">Full name</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input id="name" placeholder="Ada Lovelace" value={name} onChange={(e) => setName(e.target.value)} className="pl-10 h-12" />
                </div>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="pl-10 h-12" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input id="password" type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} className="pl-10 h-12" />
              </div>
            </div>

            <Button type="submit" variant="hero" size="lg" className="w-full mt-6">
              {mode === "login" ? "Log in" : "Create account"}
            </Button>
          </form>

          <p className="text-center text-xs text-muted-foreground mt-6">
            Demo mode — no real account is created. Data lives in your browser.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;
