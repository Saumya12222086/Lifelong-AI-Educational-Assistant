import { useState, useRef, useEffect } from "react";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Sparkles, Brain, User as UserIcon } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

interface Msg { id: string; role: "user" | "ai"; text: string }

const responses = [
  "Great question! Let's break this down step by step. The core concept here is...",
  "Imagine it like this: think of a function as a recipe — inputs go in, transformations happen, and a result comes out.",
  "That's a fascinating area. At your current level, I'd recommend exploring three angles: the intuition, the math, and a real example.",
  "Excellent! Here's how I'd approach it: first identify what's known, then what's unknown, then map the relationship.",
  "Let me adapt my explanation for you. Since you're at a more advanced stage, we can skip the basics and dive into the underlying mechanics.",
  "I love this curiosity! A common misconception is that this is purely deterministic — actually, probability plays a major role.",
];

const suggestions = [
  "Explain neural networks like I'm 12",
  "Help me solve a calculus problem",
  "Summarize the theory of relativity",
  "Suggest a study plan for this week",
];

const Chat = () => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Msg[]>([
    { id: "0", role: "ai", text: `Hi ${user?.name?.split(" ")[0] ?? "there"}! I'm your adaptive AI tutor. I'll calibrate every answer to your ${user?.level ?? "Beginner"} level. What shall we explore today?` },
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, thinking]);

  const send = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Msg = { id: crypto.randomUUID(), role: "user", text };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setThinking(true);
    setTimeout(() => {
      const reply: Msg = { id: crypto.randomUUID(), role: "ai", text: responses[Math.floor(Math.random() * responses.length)] };
      setMessages((m) => [...m, reply]);
      setThinking(false);
    }, 900 + Math.random() * 600);
  };

  return (
    <AppLayout>
      <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-5rem)] max-w-4xl mx-auto">
        <div className="mb-4">
          <h1 className="font-display text-3xl font-bold">AI Tutor</h1>
          <p className="text-muted-foreground text-sm">Adaptive responses tuned to your {user?.level} level</p>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {messages.map((m) => (
            <div key={m.id} className={`flex gap-3 animate-fade-in-up ${m.role === "user" ? "flex-row-reverse" : ""}`}>
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${m.role === "user" ? "bg-secondary" : "bg-gradient-primary"}`}>
                {m.role === "user" ? <UserIcon className="w-4 h-4 text-secondary-foreground" /> : <Brain className="w-4 h-4 text-primary-foreground" />}
              </div>
              <div className={`max-w-[80%] rounded-2xl px-4 py-3 shadow-soft ${m.role === "user" ? "bg-gradient-primary text-primary-foreground" : "bg-card"}`}>
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>
              </div>
            </div>
          ))}
          {thinking && (
            <div className="flex gap-3 animate-fade-in">
              <div className="w-9 h-9 rounded-xl bg-gradient-primary flex items-center justify-center"><Brain className="w-4 h-4 text-primary-foreground" /></div>
              <div className="bg-card rounded-2xl px-4 py-3 shadow-soft flex gap-1">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse-glow" />
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse-glow" style={{ animationDelay: "0.2s" }} />
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse-glow" style={{ animationDelay: "0.4s" }} />
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>

        {messages.length <= 1 && (
          <div className="flex flex-wrap gap-2 mt-4 mb-3">
            {suggestions.map((s) => (
              <button key={s} onClick={() => send(s)} className="text-xs px-3 py-2 rounded-full bg-card border border-border hover:bg-accent transition-smooth">
                <Sparkles className="inline w-3 h-3 mr-1 text-primary" />{s}
              </button>
            ))}
          </div>
        )}

        <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="mt-4 flex gap-2 bg-card rounded-2xl p-2 shadow-soft border border-border">
          <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask me anything..." className="border-0 bg-transparent focus-visible:ring-0 h-11" />
          <Button type="submit" variant="hero" size="icon" className="h-11 w-11"><Send className="w-4 h-4" /></Button>
        </form>
      </div>
    </AppLayout>
  );
};

export default Chat;
